README

included:
All html files and single style.css
this README
images
javascript

Student: Alistair Gillespie 20262247
Project: Project Part 1

AIM:
 

I'd like to first mention not all javascript is of my own work. I have followed tutorials and examples and used snippets of code to create my website.

I have chosen along with my group to develop a image upload service via the internet. I embarked on doing so and have come up with a simple design that I think is professional and intuitive for users. Secondly, the theme I wanted to implement involved a instagram-type spin off. Whereby, you have a profile of your own images and a feature page where 'special' images get featured that are chosen by the developers. So not only does the user gain an image upload service they also get to see other peoples work.

Immediately when arriving at Balloon you are fronted by sign up/sign in gateway. There is a specific reason for this, I wanted to keep integrity and security for such a service and protect user content.

Once the user has logged in or signed up they are immediately at their profile page were they can access all of the websites information and see their portfolio of images. They can also upload images at the home page (profile).

A mixed hierarchical layout is used with the main navigation and sub-navigation offering linear support.

Overall, Balloon is very simple and intuitive allowing for immediate user-engagement and a nice clean and un-cluttered layout. The footer also allows for very easy navigation.


GENERAL:

I have taken inspiration from various sites, most of all http://www.DropBox.com/. I appreciate the simple use of typography to achieve an artistic and creative product. I feel my use of Open Sans has enabled a very simple design using horizontal rules to become simple but effective website.Colouring of text has also played a part in the slick design. Images of the Ballons have been taken from referenced sources (below) but all other images are my own photography from around Perth.

Image References

http://www.iconarchive.com/show/harmonia-pastelis-icons-by-raindropmemory/hp-balloons-icon.html

http://www.iconarchive.com/show/my-seven-icons-by-itzikgur/Travel-Baloon-icon.html

Font Reference

http://fonts.googleapis.com/css?family=Open+Sans:400,600,800

REFERENCES

index.html:

I have used a drop-down javascript-based sign in form at the top of the page. Code is courtesy of

Lief from: http://aext.net/2009/08/perfect-sign-in-dropdown-box-likes-twitter-with-jquery/

I modified a lot of the css and positioning to come with some a little more to my taste.

In addition I have created a form with some validation to enhance the DHTML side of the website as a whole for client-side valdiation.

Javascript used to enable placeholders for non-supported browsers was based on the reference:

C.Bavota  post: http://bavotasan.com/2011/html5-placeholder-jquery-fix/
 
contact.html:
 
A reference that was helpful for my contact form:
 http://www.onextrapixel.com/2013/01/18/creating-an-html5-responsive-ready-contact-form-with-javascript-detection/
 
Javascript General:
 
Javascript used for non-support browsers for input and forms and image validation in the upload form was helped by the following references:

 Gabriel C http://www.bitrepository.com/validating-an-image-upload.html
 

SUPPORT ISSUES:

Forms in Opera


The document located at <http://student.csse.uwa.edu.au/~20262247/CITS3403/> was successfully checked as HTML5. This means that the resource in question identified itself as "HTML5" and that we successfully performed a formal validation of it. The parser implementations we used for this check are based on validator.nu (HTML5).

